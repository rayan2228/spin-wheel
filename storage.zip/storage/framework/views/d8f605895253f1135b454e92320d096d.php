<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Document</title>
</head>

<body>

    <div class="container">
        <div class="flex">
            <div class="spin">
                <div class="wheel">

                    <div class="inner-wheel">

                    </div>
                    <?php $__empty_1 = true; $__currentLoopData = $participants->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participants_chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $__currentLoopData = $participants_chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="section" data-win="<?php echo e($participant->position); ?>"
                                data-result="<?php echo e($participant->result); ?>">
                                <span><?php echo e($participant->name_or_num); ?></span>
                                <input type="hidden" name="id" value="<?php echo e($participant->id); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>

                </div>
                <div class="button-wrap">
                    <?php if($spin->setting_value): ?>
                        <span></span>
                    <?php endif; ?>
                    <div class="button">
                        <h4>SPIN</h4>
                    </div>
                </div>
            </div>
            <form action="<?php echo e(url('/')); ?>" method="post" id="remove">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="" id="removeId">
            </form>

            <div class="wrapper">
                <div class="modal">
                    <!--     <span class="emoji">👏</span> -->
                    <span class="emoji round">🏆</span>
                    <h1 class="winName"></h1>
                    <div class="modal-btn">
                        <form action="<?php echo e(url('/remove')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="" id="rayan">
                            <button>remove</button>
                        </form>
                        <form action="<?php echo e(url('/')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="" id="continueId">
                            <button>Continue</button>
                        </form>
                    </div>
                </div>
                <div id="confetti-wrapper">
                </div>
            </div>

            <div class="input ">
                <button class="filter" id="shuffle"> <i class="fa-solid fa-shuffle"></i>shuffle</button>
                <button class="filter" id="sort"><i class="fa-solid fa-arrow-down-a-z"></i>sort</button>
                <button class="filter" id="numbersort"><i class="fa-solid fa-arrow-down-a-z"></i>number sort</button>
                <button class="filter" id="result"><i class="fa-solid fa-square-poll-vertical"></i>result</button>
                <button class="filter" id="add"><i class="fa-solid fa-plus"></i>add</button>
                <button class="count"><?php echo e($participantsCount); ?></button>
                <?php if(session('success')): ?>
                    <h1 class="success"><?php echo e(session('success')); ?></h1>
                <?php endif; ?>
                <div class="addData">
                    <form action="<?php echo e(route('participants.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <textarea name="name_or_num" id="">
<?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($participant->name_or_num); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </textarea>
                        <button class="submit">Submit</button>
                    </form>
                </div>

                <div class="results">
                    <ul>
                        <?php $__currentLoopData = $winners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $winner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style="color: #0CD977"><?php echo e($winner->name_or_num); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

            </div>
        </div>
    </div>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\R A Y A N\Desktop\spin-wheel\spin-wheel\resources\views/welcome.blade.php ENDPATH**/ ?>