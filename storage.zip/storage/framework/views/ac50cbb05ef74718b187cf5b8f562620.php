<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between text-xl font-semibold leading-tight">
            <a href="<?php echo e(url('/')); ?>" target="_blank"
                class="inline-block px-5 py-3 text-gray-800 capitalize bg-green-400 rounded-lg">
                <?php echo e(__('go to website')); ?>

            </a>
            <div class="flex items-center gap-x-3">
                <form action="<?php echo e(route('settings')); ?>" id="spinShow" method="POST">
                    <?php echo csrf_field(); ?>
                    <label class="inline-block pl-[0.15rem] hover:cursor-pointer " for="flexSwitchChecked">spin</label>
                    <select name="spin" id="" onchange="document.getElementById('spinShow').submit()">
                        <option value="1" <?php if($spin->setting_value): echo 'selected'; endif; ?>>on</option>
                        <option value="0" <?php if($spin->setting_value == 0): echo 'selected'; endif; ?>>off</option>
                    </select>
                </form>
                <form action="<?php echo e(route('settingslimit')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="limit">
                    <button class="px-10 py-2 text-white capitalize bg-slate-500">set limit</button>
                </form>
                <form action="<?php echo e(url('removeAll')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button class="px-10 py-2 text-white capitalize bg-red-500">Delete All</button>
                </form>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">

            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">


                <div class="p-6 ">


                    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                        <?php if(session('success')): ?>
                            <h1 class="text-lg text-green-600"><?php echo e(session('success')); ?></h1>
                        <?php endif; ?>

                        <table class="text-left" id="example">
                            <thead>
                                <tr>
                                    <th scope="col" class="px-6 py-3">
                                        no
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        participant name or number
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        position
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        show on wheel
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        result
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        created_at
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row"
                                            class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap ">
                                            <?php echo e($loop->iteration); ?>

                                        </td>
                                        <td scope="row"
                                            class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap ">
                                            <?php echo e($participant->name_or_num); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($participant->position); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($participant->onSpin); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($participant->result); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($participant->created_at); ?>

                                        </td>
                                        <td class="px-6 py-4 ">
                                            <a href="<?php echo e(route('participants.edit', ['participant' => $participant->id])); ?>"
                                                class="font-medium text-blue-600 hover:underline"
                                                name="id">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>


                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\R A Y A N\Desktop\spin-wheel\spin-wheel\resources\views/dashboard.blade.php ENDPATH**/ ?>